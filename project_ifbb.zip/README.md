# Project IFBB — static deploy

Single-file site. No build step.

## GitHub Pages
- Commit `index.html` at repo root
- Enable Pages: Settings → Pages → Deploy from a branch → `main` / root
- Optional: add `.nojekyll` to bypass Jekyll

CDN dependencies: Tailwind, Chart.js, Google Fonts.
