Static deploy. Open index.html.
